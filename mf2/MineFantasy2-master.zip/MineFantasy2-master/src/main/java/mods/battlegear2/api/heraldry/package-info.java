@API(owner = "battlegear2", provides = "Heraldry", apiVersion = "alpha")
package mods.battlegear2.api.heraldry;

import cpw.mods.fml.common.API;

