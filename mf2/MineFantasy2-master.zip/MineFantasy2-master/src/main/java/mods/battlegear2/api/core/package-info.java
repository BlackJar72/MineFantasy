@API(owner = "battlegear2", provides = "BattlePlayer", apiVersion = "0.1")
package mods.battlegear2.api.core;

import cpw.mods.fml.common.API;

