package minefantasy.mf2.api.tier;

import net.minecraft.item.Item.ToolMaterial;

public interface IToolMaterial 
{
	/**
	 * Gets the material for outside reference
	 */
	public ToolMaterial getMaterial();
}
