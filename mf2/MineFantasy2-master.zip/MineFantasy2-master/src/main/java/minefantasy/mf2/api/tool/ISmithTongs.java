package minefantasy.mf2.api.tool;

public interface ISmithTongs {

}
