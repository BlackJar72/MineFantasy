package minefantasy.mf2.api.refine;

public interface IBellowsUseable {

	void onUsedWithBellows(float powerLevel);

}
