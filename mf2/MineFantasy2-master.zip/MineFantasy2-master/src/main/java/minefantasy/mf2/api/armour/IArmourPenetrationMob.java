package minefantasy.mf2.api.armour;

public interface IArmourPenetrationMob 
{
	public float[] getHitTraits();
}
