package minefantasy.mf2.api.crafting;

public interface IQualityBalance
{
	float getMarkerPosition();
	float getThresholdPosition();
	float getSuperThresholdPosition();
	boolean shouldShowMetre();
}
