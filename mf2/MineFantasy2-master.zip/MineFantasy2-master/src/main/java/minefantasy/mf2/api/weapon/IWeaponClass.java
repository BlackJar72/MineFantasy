package minefantasy.mf2.api.weapon;

public interface IWeaponClass
{
	public WeaponClass getWeaponClass();
}
