package minefantasy.mf2.api.rpg;

public class SkillList
{
	//MOVEMENT
	//public static Skill athletics = new Skill("athletics").register();
	//public static Skill acrobatics = new Skill("acrobatics").register();
	//public static Skill sneak = new Skill("sneak").register();
	
	//CRAFTING
	public static Skill artisanry = new Skill("artisanry").register();
	public static Skill engineering = new Skill("engineering").register();
	public static Skill construction = new Skill("construction").register();
	public static Skill provisioning = new Skill("provisioning").register();
	public static Skill combat = new Skill("combat").register();
	
	//OFFENSE
	//public static Skill unarmed = new Skill("unarmed").register();
	//public static Skill blade = new Skill("blade").register();
	//public static Skill blunt = new Skill("blunt").register();
	//public static Skill axe = new Skill("axe").register();
	//public static Skill polearm = new Skill("polearm").register();
	//public static Skill exotic = new Skill("exotic").register();
	//public static Skill archery = new Skill("archery").register();
	
	//DEFENCE
	//public static Skill lightarmour = new Skill("lightarmour").register();
	//public static Skill mediumarmour = new Skill("mediumarmour").register();
	//public static Skill heavyarmour = new Skill("heavyarmour").register();
	//public static Skill block = new Skill("block").register();
	
	public static void init() 
	{
	}
}
