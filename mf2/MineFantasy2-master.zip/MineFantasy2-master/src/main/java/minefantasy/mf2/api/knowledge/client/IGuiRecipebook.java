package minefantasy.mf2.api.knowledge.client;

public interface IGuiRecipebook
{

	int getWidth();

	int getHeight();

	int getLeft();

	int getTop();

}
