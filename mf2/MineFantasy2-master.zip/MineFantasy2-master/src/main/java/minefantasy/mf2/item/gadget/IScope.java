package minefantasy.mf2.item.gadget;

import net.minecraft.item.ItemStack;

public interface IScope {
	public float getZoom(ItemStack item);
}
