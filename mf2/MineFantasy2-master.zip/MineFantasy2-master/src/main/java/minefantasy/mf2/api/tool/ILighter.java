package minefantasy.mf2.api.tool;

public interface ILighter {

	boolean canLight();
	double getChance();

}
