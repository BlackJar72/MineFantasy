package mods.battlegear2.api.heraldry;

import cpw.mods.fml.common.API;

@API(owner="battlegear2", provides="Heraldry", apiVersion="alpha")
abstract interface package-info {}


/* Location:              /home/jared/bin/JavaDecompiler/MineFantasy-1.4.4.jar!/mods/battlegear2/api/heraldry/package-info.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */