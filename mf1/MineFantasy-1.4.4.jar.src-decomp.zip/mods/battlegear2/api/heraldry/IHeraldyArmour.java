package mods.battlegear2.api.heraldry;

public abstract interface IHeraldyArmour
  extends IHeraldryItem
{
  public abstract String getBaseArmourPath(int paramInt);
  
  public abstract String getPatternArmourPath(PatternStore paramPatternStore, int paramInt1, int paramInt2);
}


/* Location:              /home/jared/bin/JavaDecompiler/MineFantasy-1.4.4.jar!/mods/battlegear2/api/heraldry/IHeraldyArmour.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */