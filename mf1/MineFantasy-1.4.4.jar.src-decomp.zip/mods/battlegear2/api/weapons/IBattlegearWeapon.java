package mods.battlegear2.api.weapons;

import mods.battlegear2.api.IAllowItem;
import mods.battlegear2.api.IOffhandDual;
import mods.battlegear2.api.ISheathed;

public abstract interface IBattlegearWeapon
  extends ISheathed, IOffhandDual, IAllowItem
{}


/* Location:              /home/jared/bin/JavaDecompiler/MineFantasy-1.4.4.jar!/mods/battlegear2/api/weapons/IBattlegearWeapon.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */