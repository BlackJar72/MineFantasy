package mods.battlegear2.api.weapons;

import net.minecraft.entity.EntityLivingBase;

public abstract interface IBackStabbable
{
  public abstract boolean onBackStab(EntityLivingBase paramEntityLivingBase1, EntityLivingBase paramEntityLivingBase2);
}


/* Location:              /home/jared/bin/JavaDecompiler/MineFantasy-1.4.4.jar!/mods/battlegear2/api/weapons/IBackStabbable.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */