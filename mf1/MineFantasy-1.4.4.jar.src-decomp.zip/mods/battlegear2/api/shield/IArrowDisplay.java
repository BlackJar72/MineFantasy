package mods.battlegear2.api.shield;

import net.minecraft.item.ItemStack;

public abstract interface IArrowDisplay
{
  public abstract void setArrowCount(ItemStack paramItemStack, int paramInt);
  
  public abstract int getArrowCount(ItemStack paramItemStack);
}


/* Location:              /home/jared/bin/JavaDecompiler/MineFantasy-1.4.4.jar!/mods/battlegear2/api/shield/IArrowDisplay.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */