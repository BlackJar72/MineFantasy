/*   */ package minefantasy.block.special;
/*   */ 
/*   */ import minefantasy.MineFantasyBase;
/*   */ 
/*   */ public class ColouriserMF {
/*   */   public static int getFoliageColorIronbark() {
/* 7 */     return MineFantasyBase.getColourForRGB(64, 131, 54);
/*   */   }
/*   */ }


/* Location:              /home/jared/bin/JavaDecompiler/MineFantasy-1.4.4.jar!/minefantasy/block/special/ColouriserMF.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */