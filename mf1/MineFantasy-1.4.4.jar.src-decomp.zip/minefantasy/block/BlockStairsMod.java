/*    */ package minefantasy.block;
/*    */ 
/*    */ import net.minecraft.block.BlockStairs;
/*    */ 
/*    */ public class BlockStairsMod extends BlockStairs
/*    */ {
/*    */   public BlockStairsMod(int id, net.minecraft.block.Block block, int metadata)
/*    */   {
/*  9 */     super(id, block, metadata);
/* 10 */     func_71849_a(minefantasy.item.ItemListMF.tabDeco);
/*    */   }
/*    */ }


/* Location:              /home/jared/bin/JavaDecompiler/MineFantasy-1.4.4.jar!/minefantasy/block/BlockStairsMod.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */