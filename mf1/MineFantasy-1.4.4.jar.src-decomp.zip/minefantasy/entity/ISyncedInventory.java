package minefantasy.entity;

import net.minecraft.item.ItemStack;

public abstract interface ISyncedInventory
{
  public abstract void setItem(ItemStack paramItemStack, int paramInt);
}


/* Location:              /home/jared/bin/JavaDecompiler/MineFantasy-1.4.4.jar!/minefantasy/entity/ISyncedInventory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */