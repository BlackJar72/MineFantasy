package minefantasy.entity;

public abstract interface INameableEntity
{
  public abstract int getEntityID();
  
  public abstract void sendNewName(String paramString);
}


/* Location:              /home/jared/bin/JavaDecompiler/MineFantasy-1.4.4.jar!/minefantasy/entity/INameableEntity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */