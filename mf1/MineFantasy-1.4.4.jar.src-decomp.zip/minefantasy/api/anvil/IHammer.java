package minefantasy.api.anvil;

public abstract interface IHammer
{
  public abstract int getForgeLevel();
  
  public abstract float getForgeStrength();
}


/* Location:              /home/jared/bin/JavaDecompiler/MineFantasy-1.4.4.jar!/minefantasy/api/anvil/IHammer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */