/*   */ package minefantasy.api.anvil;
/*   */ 
/*   */ public class AnvilProps
/*   */ {
/* 5 */   public static int globalWidth = 8;
/* 6 */   public static int globalHeight = 5;
/*   */ }


/* Location:              /home/jared/bin/JavaDecompiler/MineFantasy-1.4.4.jar!/minefantasy/api/anvil/AnvilProps.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */