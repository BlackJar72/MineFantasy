package minefantasy.api.anvil;

public abstract interface ITongs {}


/* Location:              /home/jared/bin/JavaDecompiler/MineFantasy-1.4.4.jar!/minefantasy/api/anvil/ITongs.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */