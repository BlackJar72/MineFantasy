package minefantasy.api.forge;

public abstract interface IBellowsUseable
{
  public abstract void onUsedWithBellows(float paramFloat);
}


/* Location:              /home/jared/bin/JavaDecompiler/MineFantasy-1.4.4.jar!/minefantasy/api/forge/IBellowsUseable.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */