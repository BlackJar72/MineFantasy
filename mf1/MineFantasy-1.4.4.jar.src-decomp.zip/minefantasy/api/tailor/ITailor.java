package minefantasy.api.tailor;

public abstract interface ITailor
{
  public abstract void setStitchCount(int paramInt);
  
  public abstract void setString(int paramInt);
  
  public abstract void setSewTime(float paramFloat);
  
  public abstract void setTier(int paramInt);
}


/* Location:              /home/jared/bin/JavaDecompiler/MineFantasy-1.4.4.jar!/minefantasy/api/tailor/ITailor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */