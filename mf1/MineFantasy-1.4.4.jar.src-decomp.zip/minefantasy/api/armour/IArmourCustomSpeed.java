package minefantasy.api.armour;

import net.minecraft.item.ItemStack;

public abstract interface IArmourCustomSpeed
{
  public abstract float getMoveSpeed(ItemStack paramItemStack);
}


/* Location:              /home/jared/bin/JavaDecompiler/MineFantasy-1.4.4.jar!/minefantasy/api/armour/IArmourCustomSpeed.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */