package minefantasy.api.arrow;

import net.minecraft.entity.Entity;

public abstract interface ISpecialBow
{
  public abstract Entity modifyArrow(Entity paramEntity);
}


/* Location:              /home/jared/bin/JavaDecompiler/MineFantasy-1.4.4.jar!/minefantasy/api/arrow/ISpecialBow.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */