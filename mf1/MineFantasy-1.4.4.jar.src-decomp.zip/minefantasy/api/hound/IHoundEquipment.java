package minefantasy.api.hound;

public abstract interface IHoundEquipment
{
  public abstract int getPiece();
  
  public abstract int getRequiredStr();
  
  public abstract int getRequiredEnd();
  
  public abstract int getRequiredSta();
  
  public abstract float getMobilityModifier();
}


/* Location:              /home/jared/bin/JavaDecompiler/MineFantasy-1.4.4.jar!/minefantasy/api/hound/IHoundEquipment.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */