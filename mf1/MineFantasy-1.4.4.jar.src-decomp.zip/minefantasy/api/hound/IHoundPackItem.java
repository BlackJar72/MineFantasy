package minefantasy.api.hound;

public abstract interface IHoundPackItem
{
  public abstract String getTexture();
}


/* Location:              /home/jared/bin/JavaDecompiler/MineFantasy-1.4.4.jar!/minefantasy/api/hound/IHoundPackItem.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */