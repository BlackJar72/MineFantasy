package minefantasy.api.targeting;

public abstract interface ITargetAllyMF
{
  public abstract boolean isAlly();
  
  public abstract boolean isEnemy();
}


/* Location:              /home/jared/bin/JavaDecompiler/MineFantasy-1.4.4.jar!/minefantasy/api/targeting/ITargetAllyMF.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */