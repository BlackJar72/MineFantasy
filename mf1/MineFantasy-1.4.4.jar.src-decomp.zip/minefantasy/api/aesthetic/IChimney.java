package minefantasy.api.aesthetic;

import net.minecraft.world.World;

public abstract interface IChimney
{
  public abstract boolean puffSmoke(World paramWorld, int paramInt1, int paramInt2, int paramInt3, float paramFloat1, float paramFloat2, float paramFloat3);
}


/* Location:              /home/jared/bin/JavaDecompiler/MineFantasy-1.4.4.jar!/minefantasy/api/aesthetic/IChimney.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */