package minefantasy.api.tactic;

public abstract interface ISpecialSenses
{
  public abstract int getViewingArc();
  
  public abstract int getHearing();
  
  public abstract int getSight();
}


/* Location:              /home/jared/bin/JavaDecompiler/MineFantasy-1.4.4.jar!/minefantasy/api/tactic/ISpecialSenses.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */