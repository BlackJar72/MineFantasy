package minefantasy.api.tactic;

public abstract interface ISoundMaker
{
  public abstract boolean isMakingNoise();
  
  public abstract int getSoundStrength();
}


/* Location:              /home/jared/bin/JavaDecompiler/MineFantasy-1.4.4.jar!/minefantasy/api/tactic/ISoundMaker.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */