package minefantasy.api.tactic;

public abstract interface IStealthArmour
{
  public abstract float darknessAmplifier();
  
  public abstract float noiseReduction();
  
  public abstract boolean quietRun();
  
  public abstract boolean canTurnInvisible();
}


/* Location:              /home/jared/bin/JavaDecompiler/MineFantasy-1.4.4.jar!/minefantasy/api/tactic/IStealthArmour.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */