package minefantasy.api.cooking;

public abstract interface IHeatSource
{
  public abstract boolean canPlaceAbove();
  
  public abstract int getHeat();
}


/* Location:              /home/jared/bin/JavaDecompiler/MineFantasy-1.4.4.jar!/minefantasy/api/cooking/IHeatSource.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */