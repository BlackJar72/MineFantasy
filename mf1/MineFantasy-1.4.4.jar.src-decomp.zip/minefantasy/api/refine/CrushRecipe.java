/*    */ package minefantasy.api.refine;
/*    */ 
/*    */ import net.minecraft.item.ItemStack;
/*    */ 
/*    */ public class CrushRecipe {
/*    */   public ItemStack input;
/*    */   public ItemStack output;
/*    */   
/*    */   public CrushRecipe(ItemStack in, ItemStack out) {
/* 10 */     this.input = in;
/* 11 */     this.output = out;
/*    */   }
/*    */ }


/* Location:              /home/jared/bin/JavaDecompiler/MineFantasy-1.4.4.jar!/minefantasy/api/refine/CrushRecipe.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */