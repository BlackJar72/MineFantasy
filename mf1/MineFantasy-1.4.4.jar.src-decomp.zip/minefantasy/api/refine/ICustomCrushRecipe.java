package minefantasy.api.refine;

import net.minecraft.item.ItemStack;

public abstract interface ICustomCrushRecipe
{
  public abstract ItemStack getOutput(ItemStack paramItemStack);
}


/* Location:              /home/jared/bin/JavaDecompiler/MineFantasy-1.4.4.jar!/minefantasy/api/refine/ICustomCrushRecipe.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */