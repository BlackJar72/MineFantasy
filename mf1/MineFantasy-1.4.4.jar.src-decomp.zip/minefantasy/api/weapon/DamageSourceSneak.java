/*    */ package minefantasy.api.weapon;
/*    */ 
/*    */ import net.minecraft.util.DamageSource;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DamageSourceSneak
/*    */   extends DamageSource
/*    */ {
/*    */   public DamageSourceSneak(String title)
/*    */   {
/* 13 */     super(title);
/*    */   }
/*    */ }


/* Location:              /home/jared/bin/JavaDecompiler/MineFantasy-1.4.4.jar!/minefantasy/api/weapon/DamageSourceSneak.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */