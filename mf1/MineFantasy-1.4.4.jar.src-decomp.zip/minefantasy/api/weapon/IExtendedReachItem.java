package minefantasy.api.weapon;

import net.minecraft.item.ItemStack;

public abstract interface IExtendedReachItem
{
  public abstract float getReachModifierInBlocks(ItemStack paramItemStack);
}


/* Location:              /home/jared/bin/JavaDecompiler/MineFantasy-1.4.4.jar!/minefantasy/api/weapon/IExtendedReachItem.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */