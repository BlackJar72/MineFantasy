package minefantasy.api.weapon;

public abstract interface IWeaponMobility
{
  public abstract float getExaustion();
  
  public abstract float getSpeedWhenEquipped();
}


/* Location:              /home/jared/bin/JavaDecompiler/MineFantasy-1.4.4.jar!/minefantasy/api/weapon/IWeaponMobility.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */