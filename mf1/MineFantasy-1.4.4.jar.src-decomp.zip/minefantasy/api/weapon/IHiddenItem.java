package minefantasy.api.weapon;

public abstract interface IHiddenItem
{
  public abstract boolean doesHide();
}


/* Location:              /home/jared/bin/JavaDecompiler/MineFantasy-1.4.4.jar!/minefantasy/api/weapon/IHiddenItem.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */