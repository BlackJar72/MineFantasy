package minefantasy.api.weapon;

public abstract interface IWeaponPenetrateArmour
{
  public abstract float getAPDamage();
  
  public abstract float getArmourDamageBonus();
  
  public abstract boolean buffDamage();
}


/* Location:              /home/jared/bin/JavaDecompiler/MineFantasy-1.4.4.jar!/minefantasy/api/weapon/IWeaponPenetrateArmour.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */