package minefantasy.api.weapon;

public enum EnumAmmo
{
  BOLT,  ARROW;
  
  private EnumAmmo() {}
}


/* Location:              /home/jared/bin/JavaDecompiler/MineFantasy-1.4.4.jar!/minefantasy/api/weapon/EnumAmmo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */