package minefantasy.api.weapon;

public abstract interface IWeightedWeapon
{
  public abstract float getBalance();
  
  public abstract float getBlockFailureChance();
}


/* Location:              /home/jared/bin/JavaDecompiler/MineFantasy-1.4.4.jar!/minefantasy/api/weapon/IWeightedWeapon.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */