package minefantasy.api.weapon;

public enum EnumWeaponType
{
  SMLBLADE,  MEDBLADE,  LONGBLADE,  BIGBLADE,  SMLBLUNT,  BIGBLUNT,  SMLAXE,  AXE,  BIGAXE,  POLEARM,  BIGPOLEARM,  STAFF;
  
  private EnumWeaponType() {}
}


/* Location:              /home/jared/bin/JavaDecompiler/MineFantasy-1.4.4.jar!/minefantasy/api/weapon/EnumWeaponType.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */