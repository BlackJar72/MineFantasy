/*    */ package minefantasy.api.leatherwork;
/*    */ 
/*    */ public enum EnumToolType {
/*  4 */   KNIFE(1),  CUTTER(2);
/*    */   
/*    */   private final int id;
/*    */   
/*    */   private EnumToolType(int i) {
/*  9 */     this.id = i;
/*    */   }
/*    */   
/*    */   public int getID() {
/* 13 */     return this.id;
/*    */   }
/*    */ }


/* Location:              /home/jared/bin/JavaDecompiler/MineFantasy-1.4.4.jar!/minefantasy/api/leatherwork/EnumToolType.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */