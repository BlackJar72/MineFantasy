package minefantasy.api.leatherwork;

public abstract interface ITanningItem
{
  public abstract float getQuality();
  
  public abstract EnumToolType getType();
}


/* Location:              /home/jared/bin/JavaDecompiler/MineFantasy-1.4.4.jar!/minefantasy/api/leatherwork/ITanningItem.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */