package minefantasy.api;

public abstract interface IMineFantasyPlugin
{
  public abstract void initWithMineFantasy();
  
  public abstract String pluginName();
}


/* Location:              /home/jared/bin/JavaDecompiler/MineFantasy-1.4.4.jar!/minefantasy/api/IMineFantasyPlugin.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */