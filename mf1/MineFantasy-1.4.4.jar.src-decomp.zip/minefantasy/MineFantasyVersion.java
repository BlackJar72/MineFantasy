package minefantasy;

public class MineFantasyVersion {}


/* Location:              /home/jared/bin/JavaDecompiler/MineFantasy-1.4.4.jar!/minefantasy/MineFantasyVersion.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */