package minefantasy.system.network;

import com.google.common.io.ByteArrayDataInput;

public abstract interface PacketUserMF
{
  public abstract void recievePacket(ByteArrayDataInput paramByteArrayDataInput);
}


/* Location:              /home/jared/bin/JavaDecompiler/MineFantasy-1.4.4.jar!/minefantasy/system/network/PacketUserMF.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */