package minefantasy.client.gui.hound;

public abstract interface IBaseHoundScreen
{
  public abstract void drawText(String[] paramArrayOfString, int paramInt1, int paramInt2);
  
  public abstract void drawText(String paramString, int paramInt1, int paramInt2);
}


/* Location:              /home/jared/bin/JavaDecompiler/MineFantasy-1.4.4.jar!/minefantasy/client/gui/hound/IBaseHoundScreen.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */