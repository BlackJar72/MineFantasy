package minefantasy.item;

public abstract interface I2HWeapon
{
  public abstract boolean canSneakAttack();
}


/* Location:              /home/jared/bin/JavaDecompiler/MineFantasy-1.4.4.jar!/minefantasy/item/I2HWeapon.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */